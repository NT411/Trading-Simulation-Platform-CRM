const mgs = require('multer-gridfs-storage');
console.log('Module keys:', Object.keys(mgs));
console.log('Full export:', mgs);
